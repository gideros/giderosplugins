//
// AdHubBoxBannerView.h
// SamsungAdHub
//
// Copyright (c) 2012 Samsung Electronics Co., Ltd. All rights reserved.
//

#import "AdHubView.h"

@interface AdHubBoxBannerView : AdHubView
@end

