function ready() {
    /*
    var closeBtn = new Image();
    closeBtn.style.width = "30";
    closeBtn.style.height = "30";
    closeBtn.src = "../sad-web-root/images/closebtn.png";

    var closeDiv = document.getElementById("close");
    closeDiv.appendChild(closeBtn);
    */
}

function clickCloseButton() {
    ormma.hide();
}

function clickImage() {
    ormma.open("%@", false);
//    window.location.href = "%@";

}