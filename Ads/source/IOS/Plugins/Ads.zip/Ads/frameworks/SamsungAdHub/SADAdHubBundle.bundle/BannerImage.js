function clickImage() {
    window.location.href = "%@";
//    ormma.open("%@", false);
}